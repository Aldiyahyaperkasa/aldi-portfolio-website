/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Marquee from './components/Marquee';
import About from './components/About';
import Skills from './components/Skills';
import Projects from './components/Projects';
import Experience from './components/Experience';
import Contact from './components/Contact';
import Footer from './components/Footer';
import Cursor from './components/ui/Cursor';
import Loader from './components/ui/Loader';
import ProjectModal from './components/ProjectModal';
import { Project } from './constants';

export default function App() {
  const [isLoading, setIsLoading] = useState(true);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500);
    return () => clearTimeout(timer);
  }, []);

  return (
    <main className="relative">
      <Loader isLoading={isLoading} />
      <Cursor />
      
      {/* Badge Floating */}
      <div className="fixed bottom-[28px] right-[28px] z-[300] bg-teal rounded-full px-[22px] py-[11px] shadow-[0_8px_32px_rgba(11,85,99,0.35)] flex items-center gap-[10px] cursor-none transition-all duration-300 hover:-translate-y-[3px] hover:shadow-[0_16px_48px_rgba(11,85,99,0.4)] animate-[subad_0.8s_cubic-bezier(0.25,1,0.5,1)_1.5s_both] max-md:bottom-[16px] max-md:right-[16px]">
        <div className="w-[8px] h-[8px] bg-amber rounded-full animate-[dpb_2s_infinite]" />
        <span className="font-mono text-[12px] font-bold text-white tracking-[0.04em]">Available for Projects</span>
      </div>

      <Navbar />
      <Hero />
      <Marquee />
      <About />
      <Skills />
      <Projects onProjectClick={setSelectedProject} />
      <Experience />
      <Contact />
      <Footer />

      <ProjectModal 
        project={selectedProject} 
        onClose={() => setSelectedProject(null)} 
      />

      <style>{`
        @keyframes subad {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </main>
  );
}
