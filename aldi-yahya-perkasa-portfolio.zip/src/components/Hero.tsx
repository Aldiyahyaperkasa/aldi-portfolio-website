import { motion } from 'motion/react';
import { useEffect, useState } from 'react';

export default function Hero() {
  const [counts, setCounts] = useState({ projects: 0, users: 0, apis: 0 });

  useEffect(() => {
    // Simple counter animation logic
    const targets = { projects: 9, users: 5000, apis: 3 };
    const duration = 2000;
    const start = performance.now();

    const animate = (time: number) => {
      const elapsed = time - start;
      const progress = Math.min(elapsed / duration, 1);
      
      setCounts({
        projects: Math.floor(progress * targets.projects),
        users: Math.floor(progress * targets.users),
        apis: Math.floor(progress * targets.apis)
      });

      if (progress < 1) requestAnimationFrame(animate);
    };

    requestAnimationFrame(animate);
  }, []);

  return (
    <section id="hero" className="bg-teal min-h-screen relative overflow-hidden flex flex-col">
      {/* Background Orbs */}
      <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(ellipse_60%_50%_at_80%_20%,rgba(232,168,56,0.12)_0%,transparent_60%),radial-gradient(ellipse_50%_60%_at_10%_80%,rgba(15,126,146,0.4)_0%,transparent_60%)]" />
      <div className="absolute inset-0 pointer-events-none bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:64px_64px] [mask-image:radial-gradient(ellipse_90%_90%_at_50%_50%,black_40%,transparent_100%)]" />
      
      <div className="horb oa absolute w-[500px] h-[500px] bg-amber/10 -top-[150px] -right-[100px] rounded-full blur-[80px] animate-[obf_10s_ease-in-out_infinite]" />
      <div className="horb ob absolute w-[350px] h-[350px] bg-[#0F7E92]/20 -bottom-[100px] left-[5%] rounded-full blur-[80px] animate-[obf_10s_ease-in-out_infinite_-4s]" />
      <div className="horb oc absolute w-[250px] h-[250px] bg-coral/8 top-[40%] left-[40%] rounded-full blur-[80px] animate-[obf_10s_ease-in-out_infinite_-7s]" />

      <div className="flex-1 flex flex-col justify-center px-[52px] py-[60px] pt-[130px] relative z-[1] max-md:px-[20px] max-md:pt-[110px]">
        <motion.div 
          initial={{ opacity: 0, y: 28 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9 }}
          className="inline-flex items-center gap-[10px] bg-white/8 border border-white/12 rounded-full px-[20px] py-[7px] mb-[40px] font-mono text-[11px] text-white/70 tracking-[0.1em] uppercase w-fit"
        >
          <div className="w-[7px] h-[7px] bg-amber rounded-full animate-[dpb_2s_infinite]" />
          Fullstack Web Developer · Freelance · Bontang, Indonesia
        </motion.div>

        <motion.h1 
          initial={{ opacity: 0, y: 28 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.1 }}
          className="font-display text-[clamp(72px,13vw,180px)] leading-[0.88] tracking-[0.03em] text-white mb-[36px]"
        >
          ALDI<span className="text-amber"> YAHYA</span><br/>
          <span className="block [text-stroke:1.5px_rgba(255,255,255,0.25)] text-transparent">PERKASA</span>
        </motion.h1>

        <motion.div 
          initial={{ opacity: 0, y: 28 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.2 }}
          className="flex items-end justify-between gap-[40px] max-md:flex-col max-md:items-start max-md:gap-[24px]"
        >
          <div>
            <p className="max-w-[420px] text-[16px] text-white/65 leading-[1.75] font-light">
              Membangun sistem web end-to-end dari analisis kebutuhan, perancangan database, integrasi API, hingga deployment — untuk instansi pemerintah, event besar, dan klien korporat.
            </p>
            <div className="flex gap-[12px] mt-[24px]">
              <a href="#projects" className="bg-amber text-ink px-[30px] py-[13px] rounded-full text-[14px] font-bold no-underline inline-flex items-center gap-[8px] transition-all duration-300 hover:-translate-y-[3px] hover:shadow-[0_12px_32px_rgba(232,168,56,0.4)]">
                View Projects ↓
              </a>
              <a href="#contact" className="border-[1.5px] border-white/25 text-white/80 px-[28px] py-[13px] rounded-full text-[14px] font-medium no-underline inline-flex items-center gap-[8px] transition-all duration-250 hover:border-white hover:text-white hover:bg-white/8">
                Get In Touch →
              </a>
            </div>
          </div>

          <div className="flex flex-col gap-[24px] items-end flex-shrink-0 max-md:flex-row">
            <div>
              <div className="font-display text-[56px] text-amber line-height-[1]">{counts.projects}+</div>
              <div className="font-mono text-[10px] text-white/40 uppercase tracking-[0.12em] mt-[2px]">Projects Built</div>
            </div>
            <div>
              <div className="font-display text-[56px] text-amber line-height-[1]">{counts.users >= 1000 ? `${(counts.users/1000).toFixed(0)}K+` : counts.users}</div>
              <div className="font-mono text-[10px] text-white/40 uppercase tracking-[0.12em] mt-[2px]">Users Served</div>
            </div>
            <div>
              <div className="font-display text-[56px] text-amber line-height-[1]">{counts.apis}+</div>
              <div className="font-mono text-[10px] text-white/40 uppercase tracking-[0.12em] mt-[2px]">API Integrations</div>
            </div>
          </div>
        </motion.div>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 28 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.9, delay: 0.4 }}
        className="absolute bottom-[36px] left-[52px] z-[1] flex items-center gap-[12px] font-mono text-[10px] text-white/35 uppercase tracking-[0.14em] max-md:left-[20px]"
      >
        <div className="w-[44px] h-[1px] bg-white/15 relative overflow-hidden">
          <div className="absolute top-0 left-[-100%] w-full h-full bg-amber animate-[strn_2.2s_ease_infinite]" />
        </div>
        Scroll to explore
      </motion.div>
    </section>
  );
}
